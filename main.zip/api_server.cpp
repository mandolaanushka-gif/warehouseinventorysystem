#include "wims.h"
#include <limits>

// ================= API SERVER =================

class APIServer
{
private:
    WarehouseSystem& system;
    bool running;

    void showRoutes()
    {
        cout << "\n========== WIMS API ROUTES ==========\n";

        cout << "GET    /api/products\n";
        cout << "GET    /api/products/search\n";
        cout << "POST   /api/products/add\n";
        cout << "PUT    /api/products/update\n";
        cout << "DELETE /api/products/delete\n";
        cout << "GET    /api/transactions\n";
        cout << "GET    /api/orders\n";
        cout << "POST   /api/orders/add\n";
        cout << "POST   /api/orders/process\n";

        cout << "=====================================\n";
    }

    void processRequest(string method, string endpoint)
    {
        int id, quantity;
        double price;
        string name, expiry;

        cout << "\nRequest: " << method
             << " " << endpoint << endl;

        if (method == "GET" &&
            endpoint == "/api/products")
        {
            system.displayProducts();
        }

        else if (method == "GET" &&
                 endpoint == "/api/products/search")
        {
            cout << "Enter Product ID: ";
            cin >> id;

            Product* product = system.searchProduct(id);

            if (product == NULL)
            {
                cout << "\nProduct not found!\n";
            }
            else
            {
                cout << "\nProduct ID: " << product->getId();
                cout << "\nName: " << product->getName();
                cout << "\nQuantity: " << product->getQuantity();
                cout << "\nPrice: " << product->getPrice();
                cout << "\nExpiry: " << product->getExpiry();
                cout << endl;
            }
        }

        else if (method == "POST" &&
                 endpoint == "/api/products/add")
        {
            cout << "Enter Product Name: ";
            getline(cin >> ws, name);

            cout << "Enter Quantity: ";
            cin >> quantity;

            cout << "Enter Price: ";
            cin >> price;

            cout << "Enter Expiry Date: ";
            getline(cin >> ws, expiry);

            system.addProduct(name, quantity, price, expiry);
        }

        else if (method == "PUT" &&
                 endpoint == "/api/products/update")
        {
            cout << "Enter Product ID: ";
            cin >> id;

            cout << "Enter New Name: ";
            getline(cin >> ws, name);

            cout << "Enter New Quantity: ";
            cin >> quantity;

            cout << "Enter New Price: ";
            cin >> price;

            cout << "Enter New Expiry: ";
            getline(cin >> ws, expiry);

            system.updateProduct(id, name, quantity, price, expiry);
        }

        else if (method == "DELETE" &&
                 endpoint == "/api/products/delete")
        {
            cout << "Enter Product ID: ";
            cin >> id;

            system.deleteProduct(id);
        }

        else if (method == "GET" &&
                 endpoint == "/api/transactions")
        {
            system.displayTransactions();
        }

        else if (method == "GET" &&
                 endpoint == "/api/orders")
        {
            system.displayOrders();
        }

        else if (method == "POST" &&
                 endpoint == "/api/orders/add")
        {
            cout << "Enter Product ID: ";
            cin >> id;

            cout << "Enter Order Quantity: ";
            cin >> quantity;

            system.placeOrder(id, quantity);
        }

        else if (method == "POST" &&
                 endpoint == "/api/orders/process")
        {
            system.processNextOrder();
        }

        else
        {
            cout << "\n404 - API Endpoint Not Found!\n";
        }
    }

public:

    APIServer(WarehouseSystem& system)
        : system(system)
    {
        running = false;
    }

    void start()
    {
        running = true;

        cout << "\n================================\n";
        cout << "       WIMS API SERVER\n";
        cout << "================================\n";

        showRoutes();

        while (running)
        {
            string method, endpoint;

            cout << "\nEnter HTTP Method (GET/POST/PUT/DELETE)";
            cout << "\nEnter STOP to exit API Server\n";

            cout << "\nMethod: ";
            cin >> method;

            if (method == "STOP" || method == "stop")
            {
                running = false;
                break;
            }

            cout << "Endpoint: ";
            cin >> endpoint;

            processRequest(method, endpoint);
        }

        cout << "\nWIMS API Server stopped.\n";
    }
};

// Function to start API server

void runAPIServer(WarehouseSystem& system)
{
    APIServer server(system);
    server.start();
}